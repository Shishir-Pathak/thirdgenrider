import mysql from "mysql2/promise";

const pool = mysql.createPool({
	host: process.env.DB_HOST,
	user: process.env.DB_USER,
	password: process.env.DB_PASSWORD,
	database: process.env.DB_NAME,
	port: process.env.DB_PORT || 3306,
	waitForConnections: true,
	connectionLimit: 10,
	queueLimit: 0,
});

const connectDB = async () => {
	try {
		const connection = await pool.getConnection();
		console.log("MySQL Connected");
		connection.release();
	} catch (err) {
		console.error("MySQL Connection Error:", err.message);
		process.exit(1);
	}
};

export { pool };
export default connectDB;